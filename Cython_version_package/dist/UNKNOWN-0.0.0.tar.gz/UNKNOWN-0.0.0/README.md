# LSHlink_Cython

This is a package that provides functions that implements LSH-link algorithm. This algorithm is an approximation algorithm of the single-linkage method. Similar, but faster.

[STA663-Project-LSHLink](https://github.com/Brian1357/STA663-Project-LSHLink)

